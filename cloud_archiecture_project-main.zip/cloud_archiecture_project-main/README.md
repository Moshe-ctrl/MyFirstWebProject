# cloud_archiecture_project
resume purposes
